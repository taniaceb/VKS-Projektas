﻿create table cv (
Id int Identity(1,1) Primary key,
JobSeekerId int,
CvFile varchar (255)
)