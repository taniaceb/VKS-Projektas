﻿create table category (
Id int Identity(1,1) Primary key,
CategName varchar (255)
)