﻿alter table [cv] add 
[PersonDescription] varchar(max) default NULL