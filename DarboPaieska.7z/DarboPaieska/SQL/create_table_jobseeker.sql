﻿create table jobseeker (
Id int Identity(1,1) Primary key,
CategoryId int,
FirstName varchar(255),
LastName varchar(255),
Email varchar(255),
Phone varchar(255),
JsPassword varchar(255)

)