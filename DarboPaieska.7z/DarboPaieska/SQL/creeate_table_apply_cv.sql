﻿create table apply_cv (
Id int Identity (1,1) primary key,
job_ad_Id int, jobseekerId int)