﻿create table company(
Id int Identity (1,1) Primary key,
CompName varchar(255),
CompCode varchar (255),
CompPhone varchar (255),
CompEmail varchar (255),
ContactPerson varchar (255),
CompPassword varchar (255)
)