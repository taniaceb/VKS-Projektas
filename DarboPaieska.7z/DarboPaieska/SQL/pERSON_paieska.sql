﻿select Id from jobseeker
where Email='frankas@gmail.com' and JsPassword='kestas'